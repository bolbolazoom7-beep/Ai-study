/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { sanitizeTextForSpeech } from './text.ts';

let cachedVoices: SpeechSynthesisVoice[] = [];

if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  cachedVoices = window.speechSynthesis.getVoices();
  window.speechSynthesis.onvoiceschanged = () => {
    cachedVoices = window.speechSynthesis.getVoices();
  };
}

/**
 * Instant speech playback using the browser's native Web Speech API.
 * Starts with 0 latency (no waiting for remote server TTS).
 */
export function playInstantSpeech(
  rawText: string,
  callbacks?: {
    onStart?: () => void;
    onEnd?: () => void;
    onError?: (err?: any) => void;
  }
): boolean {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return false;
  }

  try {
    // 1. Immediately cancel any pending/stuck speech and resume synthesizer
    window.speechSynthesis.cancel();
    window.speechSynthesis.resume();

    // 2. Prepare clean, spoken Arabic text (up to 400 characters for high responsiveness)
    const cleanText = sanitizeTextForSpeech(rawText).slice(0, 450);
    if (!cleanText.trim()) return false;

    // 3. Find the best Arabic voice
    if (cachedVoices.length === 0) {
      cachedVoices = window.speechSynthesis.getVoices();
    }
    const arabicVoice =
      cachedVoices.find((v) => v.lang === 'ar-EG') ||
      cachedVoices.find((v) => v.lang.startsWith('ar')) ||
      null;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    if (arabicVoice) {
      utterance.voice = arabicVoice;
    }
    utterance.lang = 'ar-SA';
    utterance.rate = 1.1; // Lively and natural teacher rhythm
    utterance.pitch = 1.0;

    utterance.onstart = () => {
      callbacks?.onStart?.();
    };

    utterance.onend = () => {
      callbacks?.onEnd?.();
    };

    utterance.onerror = (e) => {
      console.warn('Speech synthesis error/cancelled:', e);
      callbacks?.onError?.(e);
    };

    // 4. Trigger speech immediately
    window.speechSynthesis.speak(utterance);
    return true;
  } catch (error) {
    console.error('Failed to trigger instant speech:', error);
    callbacks?.onError?.(error);
    return false;
  }
}

export function stopInstantSpeech(): void {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}
