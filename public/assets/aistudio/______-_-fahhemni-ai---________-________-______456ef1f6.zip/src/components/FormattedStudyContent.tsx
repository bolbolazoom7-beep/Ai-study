/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Lightbulb, Compass, Award, CheckCircle2, BookOpen } from 'lucide-react';

interface FormattedStudyContentProps {
  content: string;
  className?: string;
}

// Clean unescaped or broken technical strings into clean Arabic text
export function sanitizeMathAndMarkdown(text: string): string {
  if (!text) return '';
  return text
    // Replace LaTeX fraction: \frac{a}{b} -> (a ÷ b)
    .replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '($1 ÷ $2)')
    // Common math symbols
    .replace(/\\times/g, ' × ')
    .replace(/\\div/g, ' ÷ ')
    .replace(/\\pm/g, ' ± ')
    .replace(/\\approx/g, ' ≈ ')
    .replace(/\\leq?/g, ' ≤ ')
    .replace(/\\geq?/g, ' ≥ ')
    .replace(/\\neq?/g, ' ≠ ')
    .replace(/\\infty/g, ' ∞ ')
    .replace(/\\sqrt\{([^}]+)\}/g, '√($1)')
    .replace(/\\cdot/g, ' · ')
    .replace(/\\text\{([^}]+)\}/g, '$1')
    // Remove raw dollar signs for inline/block latex
    .replace(/\$\$/g, '')
    .replace(/\$([^\$]+)\$/g, '$1')
    // Remove weird backslash escaping
    .replace(/\\([a-zA-Z]+)/g, '$1');
}

export const FormattedStudyContent: React.FC<FormattedStudyContentProps> = ({
  content,
  className = '',
}) => {
  const sanitized = sanitizeMathAndMarkdown(content);
  const blocks = sanitized.split('\n\n').filter((b) => b.trim().length > 0);

  return (
    <div className={`space-y-3 text-xs sm:text-sm leading-relaxed ${className}`}>
      {blocks.map((block, idx) => {
        const trimmed = block.trim();

        // 1. Heading 3 or 2
        if (trimmed.startsWith('### ') || trimmed.startsWith('## ') || trimmed.startsWith('# ')) {
          const title = trimmed.replace(/^#+\s*/, '');

          // Check if heading has a special category icon
          let icon = <BookOpen className="w-4 h-4 text-purple-600 dark:text-purple-400" />;
          let cardStyle = 'border-purple-200 dark:border-purple-800/60 bg-purple-50/70 dark:bg-purple-950/40 text-purple-900 dark:text-purple-200';

          if (title.includes('قانون') || title.includes('القاعدة') || title.includes('📐')) {
            icon = <Compass className="w-4 h-4 text-amber-600 dark:text-amber-400" />;
            cardStyle = 'border-amber-200 dark:border-amber-800/60 bg-amber-50/70 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200';
          } else if (title.includes('ناتج') || title.includes('النتيجة') || title.includes('🎯')) {
            icon = <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />;
            cardStyle = 'border-emerald-200 dark:border-emerald-800/60 bg-emerald-50/70 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200';
          } else if (title.includes('نصيحة') || title.includes('💡') || title.includes('تنبيه')) {
            icon = <Lightbulb className="w-4 h-4 text-blue-600 dark:text-blue-400" />;
            cardStyle = 'border-blue-200 dark:border-blue-800/60 bg-blue-50/70 dark:bg-blue-950/40 text-blue-900 dark:text-blue-200';
          }

          return (
            <div
              key={idx}
              className={`p-2.5 rounded-xl border flex items-center gap-2 font-bold text-xs sm:text-sm ${cardStyle} shadow-2xs`}
            >
              {icon}
              <span>{title}</span>
            </div>
          );
        }

        // 2. Final Result Callout Card
        if (trimmed.startsWith('🎯') || trimmed.includes('الناتج النهائي:') || trimmed.includes('الإجابة النهائية:')) {
          return (
            <div
              key={idx}
              className="p-3.5 rounded-2xl bg-emerald-500/10 dark:bg-emerald-500/15 border-2 border-emerald-500/30 text-emerald-950 dark:text-emerald-200 font-bold space-y-1 shadow-sm"
            >
              <div className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400">
                <Award className="w-4 h-4" />
                <span>النتيجة الصحيحة والمؤكدة:</span>
              </div>
              <p className="text-sm sm:text-base text-emerald-800 dark:text-emerald-100 font-extrabold pr-1">
                {trimmed.replace(/^🎯\s*/, '')}
              </p>
            </div>
          );
        }

        // 3. Tip / Golden Advice Card
        if (trimmed.startsWith('💡') || trimmed.includes('نصيحة ذهبية')) {
          return (
            <div
              key={idx}
              className="p-3 rounded-2xl bg-amber-500/10 dark:bg-amber-500/15 border border-amber-500/30 text-amber-950 dark:text-amber-200 flex items-start gap-2 text-xs sm:text-sm"
            >
              <Lightbulb className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium leading-relaxed">
                {trimmed.replace(/^💡\s*/, '')}
              </div>
            </div>
          );
        }

        // 4. Numbered Steps or Bullet Lists
        const lines = trimmed.split('\n');
        if (lines.length > 1 && lines.some((l) => /^\s*(\d+|[٠-٩]+|[*-])[\.\)]\s*/.test(l))) {
          return (
            <div key={idx} className="space-y-1.5 my-1.5">
              {lines.map((line, lIdx) => {
                const stepMatch = line.match(/^\s*(\d+|[٠-٩]+)[\.\)]\s*(.*)$/);
                const bulletMatch = line.match(/^\s*[*-]\s*(.*)$/);

                if (stepMatch) {
                  return (
                    <div key={lIdx} className="flex items-start gap-2.5 p-1.5 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      <span className="w-5 h-5 rounded-full bg-purple-600 text-white font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                        {stepMatch[1]}
                      </span>
                      <p className="flex-1 text-slate-800 dark:text-slate-200 leading-relaxed">
                        {renderBoldText(stepMatch[2])}
                      </p>
                    </div>
                  );
                }

                if (bulletMatch) {
                  return (
                    <div key={lIdx} className="flex items-start gap-2 pr-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-500 shrink-0 mt-2" />
                      <p className="flex-1 text-slate-700 dark:text-slate-300 leading-relaxed">
                        {renderBoldText(bulletMatch[1])}
                      </p>
                    </div>
                  );
                }

                return (
                  <p key={lIdx} className="text-slate-800 dark:text-slate-200 leading-relaxed">
                    {renderBoldText(line)}
                  </p>
                );
              })}
            </div>
          );
        }

        // 5. Normal paragraph with bold highlights
        return (
          <p key={idx} className="text-slate-800 dark:text-slate-200 leading-relaxed">
            {renderBoldText(trimmed)}
          </p>
        );
      })}
    </div>
  );
};

// Helper to parse **bold** text and render clean span tags with styled contrast
function renderBoldText(text: string): React.ReactNode {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return (
        <strong key={i} className="font-extrabold text-purple-700 dark:text-purple-300 px-0.5">
          {part.slice(2, -2)}
        </strong>
      );
    }
    return part;
  });
}
