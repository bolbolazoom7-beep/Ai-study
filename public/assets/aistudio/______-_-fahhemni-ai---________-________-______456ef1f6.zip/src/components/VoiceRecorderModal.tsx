/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Mic, Square, Trash2, Send, X, AlertCircle, Sparkles, RefreshCw } from 'lucide-react';
import { AppLanguage } from '../types.ts';

interface VoiceRecorderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitTranscription: (transcription: string) => void;
  language: AppLanguage;
  customApiKey?: string;
}

export const VoiceRecorderModal: React.FC<VoiceRecorderModalProps> = ({
  isOpen,
  onClose,
  onSubmitTranscription,
  customApiKey,
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const [transcriptionText, setTranscriptionText] = useState('');
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const transcriptRef = useRef<string>('');
  const speechRecognitionRef = useRef<any>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isOpen) {
      // Auto-start recording when modal opens for immediate, frictionless experience
      startRecording();
    } else {
      handleCancel();
    }
    return () => {
      handleCancel();
    };
  }, [isOpen]);

  const startRecording = async () => {
    setErrorMessage(null);
    setTranscriptionText('');
    transcriptRef.current = '';
    setDuration(0);
    audioChunksRef.current = [];

    // 1. Instant client-side speech recognition with Arabic (Egypt/Standard)
    const windowAny = window as any;
    const SpeechRecognition = windowAny.SpeechRecognition || windowAny.webkitSpeechRecognition;

    if (SpeechRecognition) {
      try {
        const recognition = new SpeechRecognition();
        recognition.lang = 'ar-EG';
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.maxAlternatives = 1;

        recognition.onresult = (event: any) => {
          let current = '';
          for (let i = 0; i < event.results.length; i++) {
            current += event.results[i][0].transcript + ' ';
          }
          const text = current.trim();
          transcriptRef.current = text;
          setTranscriptionText(text);
        };

        recognition.onerror = (event: any) => {
          console.warn('SpeechRecognition error:', event.error);
        };

        recognition.start();
        speechRecognitionRef.current = recognition;
      } catch (e) {
        console.warn('SpeechRecognition not available or failed:', e);
      }
    }

    // 2. High-quality MediaRecorder audio stream
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeTypes = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg', 'audio/mp4'];
      const supportedMime = mimeTypes.find((type) => MediaRecorder.isTypeSupported(type)) || '';

      const mediaRecorder = supportedMime
        ? new MediaRecorder(stream, { mimeType: supportedMime })
        : new MediaRecorder(stream);

      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, {
          type: mediaRecorder.mimeType || 'audio/webm',
        });
        stream.getTracks().forEach((track) => track.stop());

        // If local speech recognition didn't yield text, immediately query server transcription
        if (!transcriptRef.current.trim() && blob.size > 1000) {
          transcribeWithServer(blob);
        }
      };

      mediaRecorder.start(250);
      setIsRecording(true);
      timerRef.current = setInterval(() => {
        setDuration((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.error('Microphone access denied:', err);
      setIsRecording(false);
      setErrorMessage(
        'تعذر الوصول إلى الميكروفون. يرجى التأكد من السماح بالصلاحيات أو كتابة السؤال مباشرة.'
      );
    }
  };

  const stopRecording = () => {
    if (speechRecognitionRef.current) {
      try {
        speechRecognitionRef.current.stop();
      } catch {}
      speechRecognitionRef.current = null;
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {}
    }

    setIsRecording(false);
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const transcribeWithServer = async (blob: Blob) => {
    setIsTranscribing(true);
    setErrorMessage(null);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = async () => {
        const base64Audio = reader.result as string;
        const res = await fetch('/api/transcribe-audio', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            audioData: base64Audio,
            mimeType: blob.type || 'audio/webm',
            customApiKey,
          }),
        });

        const data = await res.json();
        if (data.transcription && data.transcription.trim()) {
          const finalStr = data.transcription.trim();
          transcriptRef.current = finalStr;
          setTranscriptionText(finalStr);
        } else if (!transcriptRef.current.trim()) {
          setErrorMessage('لم يتم التقاط صوت واضح. يمكنك إعادة التسجيل أو كتابة السؤال.');
        }
        setIsTranscribing(false);
      };
    } catch {
      setIsTranscribing(false);
      if (!transcriptRef.current.trim()) {
        setErrorMessage('تعذر تحويل الصوت. يمكنك كتابة سؤالك في الشات مباشرة.');
      }
    }
  };

  const handleCancel = () => {
    stopRecording();
    setIsTranscribing(false);
    setTranscriptionText('');
    transcriptRef.current = '';
    setDuration(0);
    setErrorMessage(null);
  };

  const handleSend = () => {
    const finalContent = (transcriptionText || transcriptRef.current).trim();
    if (!finalContent) return;
    onSubmitTranscription(finalContent);
    handleCancel();
    onClose();
  };

  if (!isOpen) return null;

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-fadeIn"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-md bg-white dark:bg-[#0E131F] border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-2xl flex flex-col animate-slideUp">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-100 dark:bg-purple-950 border border-purple-200 dark:border-purple-800/40 flex items-center justify-center text-purple-600 dark:text-purple-400">
              <Mic className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                تحدث مع الأستاذ بالصوت
              </h2>
              <span className="text-[10px] text-purple-600 dark:text-purple-400 font-semibold">
                تسجيل واستجابة فائقة السرعة
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-xl text-slate-400 hover:text-slate-800 dark:hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Recording Visualizer & Status */}
        <div className="py-6 flex flex-col items-center justify-center space-y-4">
          <div className="relative">
            {isRecording && (
              <>
                <span className="absolute inset-0 rounded-full bg-purple-600/20 animate-ping" />
                <span className="absolute -inset-2 rounded-full bg-purple-600/10 animate-pulse" />
              </>
            )}
            <button
              type="button"
              onClick={isRecording ? stopRecording : startRecording}
              className={`relative z-10 w-20 h-20 rounded-full flex items-center justify-center text-white transition-all transform active:scale-95 shadow-xl ${
                isRecording
                  ? 'bg-rose-600 shadow-rose-600/30'
                  : 'bg-gradient-to-tr from-purple-600 to-indigo-600 shadow-purple-600/30'
              }`}
              title={isRecording ? 'إيقاف التسجيل' : 'بدء التسجيل'}
            >
              {isRecording ? <Square className="w-7 h-7 fill-white" /> : <Mic className="w-8 h-8" />}
            </button>
          </div>

          <div className="text-center">
            {isRecording ? (
              <div className="space-y-1">
                <span className="text-sm font-extrabold text-rose-600 flex items-center justify-center gap-1.5 animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-rose-600" />
                  <span>الأستاذ يستمع لسؤالك الآن...</span>
                </span>
                <span className="text-xs font-mono font-bold text-slate-500">
                  {formatSeconds(duration)}
                </span>
              </div>
            ) : isTranscribing ? (
              <div className="text-xs font-bold text-purple-600 flex items-center gap-2">
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>جاري معالجة الصوت وتحويله لكلمات...</span>
              </div>
            ) : (
              <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                اضغط على الميكروفون للتحدث مرة أخرى
              </span>
            )}
          </div>
        </div>

        {/* Live Transcription Box (Editable) */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
            <span>الكلام المسجل:</span>
            {transcriptionText && (
              <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">
                تم التقاط الصوت بنجاح ✓
              </span>
            )}
          </label>
          <div className="relative">
            <textarea
              value={transcriptionText}
              onChange={(e) => {
                setTranscriptionText(e.target.value);
                transcriptRef.current = e.target.value;
              }}
              placeholder={
                isRecording
                  ? 'تحدث الآن، ستظهر كلماتك هنا مباشرة...'
                  : 'سيظهر نص سؤالك هنا لتعديله أو إرساله للأستاذ...'
              }
              rows={3}
              className="w-full p-3 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 outline-none focus:border-purple-600 resize-none leading-relaxed"
            />
          </div>
        </div>

        {/* Error message */}
        {errorMessage && (
          <div className="mt-3 p-2.5 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900/40 text-red-600 dark:text-red-400 text-xs flex items-center gap-2 animate-fadeIn">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Modal Actions */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={handleCancel}
            className="px-3 py-2 rounded-xl text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 text-xs font-bold flex items-center gap-1"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>مسح وإعادة</span>
          </button>

          <button
            type="button"
            onClick={handleSend}
            disabled={!transcriptionText.trim() || isTranscribing}
            className="flex-1 max-w-[180px] h-10 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-40 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-purple-600/25 transition-all active:scale-95"
          >
            <Send className="w-3.5 h-3.5 transform rotate-180" />
            <span>إرسال للأستاذ ⚡</span>
          </button>
        </div>
      </div>
    </div>
  );
};
