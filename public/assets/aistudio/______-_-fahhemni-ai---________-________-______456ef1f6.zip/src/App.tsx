/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header.tsx';
import { Navigation } from './components/Navigation.tsx';
import { AITeacherChat } from './components/AITeacherChat.tsx';
import { ScanScreen } from './components/ScanScreen.tsx';
import { QuizScreen } from './components/QuizScreen.tsx';
import { LibraryScreen } from './components/LibraryScreen.tsx';
import { VoiceRecorderModal } from './components/VoiceRecorderModal.tsx';
import { SettingsModal } from './components/SettingsModal.tsx';
import {
  AppTab,
  AnalysisMode,
  EducationalAnalysis,
  Conversation,
  ChatMessage,
  UserPreferences,
  SavedExplanation,
  Quiz,
  QuizDifficulty,
} from './types.ts';
import {
  loadSettingsFromStorage,
  saveSettingsToStorage,
  loadExplanationsFromStorage,
  saveExplanationsToStorage,
  loadConversationsFromStorage,
  saveConversationsToStorage,
  loadQuizzesFromStorage,
  saveQuizzesToStorage,
  addOrUpdateExplanation,
  removeExplanation,
  addOrUpdateConversation,
  removeConversation,
  renameConversation,
  clearAllLocalData,
} from './utils/storage.ts';
import { playInstantSpeech } from './utils/speech.ts';

export default function App() {
  const [preferences, setPreferences] = useState<UserPreferences>(() => loadSettingsFromStorage());
  const [currentTab, setCurrentTab] = useState<AppTab>('tutor');

  // Study Data
  const [savedExplanations, setSavedExplanations] = useState<SavedExplanation[]>(() =>
    loadExplanationsFromStorage()
  );
  const [quizzes, setQuizzes] = useState<Quiz[]>(() => loadQuizzesFromStorage());
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    const loaded = loadConversationsFromStorage();
    if (loaded.length > 0) return loaded;
    return [
      {
        id: 'conv-default',
        title: 'محادثة المذاكرة الأولى',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        messages: [],
      },
    ];
  });
  const [activeConversationId, setActiveConversationId] = useState<string>(
    conversations[0]?.id || 'conv-default'
  );

  // Active quiz generator topic
  const [quizInitialTopic, setQuizInitialTopic] = useState('');

  // Loading & Generation states
  const [isGeneratingChat, setIsGeneratingChat] = useState(false);
  const [isAnalyzingImage, setIsAnalyzingImage] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Modals
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Sync settings and HTML theme
  useEffect(() => {
    saveSettingsToStorage(preferences);
    const html = document.documentElement;
    html.setAttribute('dir', 'rtl');
    html.setAttribute('lang', 'ar');
    if (preferences.theme === 'light') {
      html.classList.remove('dark');
      document.body.className =
        'bg-[#F8FAFC] text-slate-800 antialiased selection:bg-purple-600/30 selection:text-purple-700 h-[100dvh] overflow-hidden';
    } else {
      html.classList.add('dark');
      document.body.className =
        'bg-[#0B0F19] text-slate-100 antialiased selection:bg-purple-600/30 selection:text-purple-200 h-[100dvh] overflow-hidden';
    }
  }, [preferences]);

  // Sync saved items
  useEffect(() => {
    saveExplanationsToStorage(savedExplanations);
  }, [savedExplanations]);

  useEffect(() => {
    saveConversationsToStorage(conversations);
  }, [conversations]);

  useEffect(() => {
    saveQuizzesToStorage(quizzes);
  }, [quizzes]);

  // -------------------------------------------------------------
  // Ultra-Fast Real-Time Streaming Chat Handler (SSE)
  // -------------------------------------------------------------
  const handleSendChatMessage = async (text: string, images?: string[]) => {
    const currentConv = conversations.find((c) => c.id === activeConversationId);
    if (!currentConv) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      text,
      images,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const assistantMsgId = `msg-${Date.now() + 1}`;
    const initialAssistantMsg: ChatMessage = {
      id: assistantMsgId,
      role: 'model',
      text: '',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isStreaming: true,
    };

    const updatedMessages = [...currentConv.messages, userMsg];
    const convWithUserAndPlaceholder: Conversation = {
      ...currentConv,
      messages: [...updatedMessages, initialAssistantMsg],
      title:
        currentConv.messages.length === 0 && text
          ? text.slice(0, 30)
          : currentConv.title,
      updatedAt: new Date().toISOString(),
    };

    setConversations((prev) => addOrUpdateConversation(prev, convWithUserAndPlaceholder));
    setIsGeneratingChat(true);

    const abortController = new AbortController();
    abortControllerRef.current = abortController;

    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (preferences.customApiKey) {
        headers['x-gemini-key'] = preferences.customApiKey;
      }

      // 1. First attempt: Ultra-fast Server-Sent Events stream
      const response = await fetch('/api/chat-stream', {
        method: 'POST',
        headers,
        signal: abortController.signal,
        body: JSON.stringify({
          messages: updatedMessages.map((m) => ({
            role: m.role,
            text: m.text,
            images: m.images,
          })),
          dialect: preferences.dialect,
          learningLevel: preferences.learningLevel,
          customApiKey: preferences.customApiKey,
        }),
      });

      if (!response.ok) {
        // Fallback to standard chat endpoint if streaming endpoint is unavailable
        const fallbackRes = await fetch('/api/chat', {
          method: 'POST',
          headers,
          signal: abortController.signal,
          body: JSON.stringify({
            messages: updatedMessages.map((m) => ({
              role: m.role,
              text: m.text,
              images: m.images,
            })),
            dialect: preferences.dialect,
            learningLevel: preferences.learningLevel,
            customApiKey: preferences.customApiKey,
          }),
        });

        if (!fallbackRes.ok) {
          const errData = await fallbackRes.json();
          throw new Error(errData.error || 'فشل الاتصال بالأستاذ الذكي.');
        }

        const data = await fallbackRes.json();
        setConversations((prev) =>
          prev.map((c) =>
            c.id === convWithUserAndPlaceholder.id
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMsgId
                      ? { ...m, text: data.text, isStreaming: false, model: data.model }
                      : m
                  ),
                }
              : c
          )
        );
        return;
      }

      // Read SSE stream chunks in real-time
      const reader = response.body?.getReader();
      const decoder = new TextDecoder('utf-8');
      let accumulatedText = '';

      if (reader) {
        let streamBuffer = '';
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          streamBuffer += decoder.decode(value, { stream: true });
          const parts = streamBuffer.split('\n\n');
          streamBuffer = parts.pop() || '';

          for (const part of parts) {
            const trimmedPart = part.trim();
            if (trimmedPart.startsWith('data: ')) {
              const dataPayload = trimmedPart.slice(6).trim();
              if (dataPayload === '[DONE]') {
                break;
              }
              try {
                const parsed = JSON.parse(dataPayload);
                if (parsed.text) {
                  accumulatedText += parsed.text;
                  const currentFullText = accumulatedText;
                  setConversations((prev) =>
                    prev.map((c) =>
                      c.id === convWithUserAndPlaceholder.id
                        ? {
                            ...c,
                            messages: c.messages.map((m) =>
                              m.id === assistantMsgId
                                ? { ...m, text: currentFullText, isStreaming: true }
                                : m
                            ),
                          }
                        : c
                    )
                  );
                }
              } catch {
                // Ignore partial JSON
              }
            }
          }
        }
      }

      // Mark streaming as complete
      setConversations((prev) =>
        prev.map((c) =>
          c.id === convWithUserAndPlaceholder.id
            ? {
                ...c,
                messages: c.messages.map((m) =>
                  m.id === assistantMsgId
                    ? { ...m, text: accumulatedText || 'تم الشرح بنجاح.', isStreaming: false }
                    : m
                ),
                updatedAt: new Date().toISOString(),
              }
            : c
        )
      );

      // Auto Read Aloud if enabled in preferences (0-delay instant speech)
      if (preferences.autoReadAloud && accumulatedText) {
        playInstantSpeech(accumulatedText);
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        const errorText = err.message || 'حدث خطأ في الاتصال. يرجى إعادة المحاولة.';
        setConversations((prev) =>
          prev.map((c) =>
            c.id === convWithUserAndPlaceholder.id
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMsgId
                      ? { ...m, text: `⚠️ ${errorText}`, isStreaming: false }
                      : m
                  ),
                }
              : c
          )
        );
      }
    } finally {
      setIsGeneratingChat(false);
      abortControllerRef.current = null;
    }
  };

  const handleStopChatGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsGeneratingChat(false);
  };

  // -------------------------------------------------------------
  // Conversation Management
  // -------------------------------------------------------------
  const handleNewConversation = () => {
    const newConv: Conversation = {
      id: `conv-${Date.now()}`,
      title: 'محادثة مذاكرة جديدة',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: [],
    };
    setConversations((prev) => [newConv, ...prev]);
    setActiveConversationId(newConv.id);
  };

  const handleRenameConversation = (id: string, newTitle: string) => {
    setConversations((prev) => renameConversation(prev, id, newTitle));
  };

  const handleDeleteConversation = (id: string) => {
    const updated = removeConversation(conversations, id);
    setConversations(updated);
    if (activeConversationId === id) {
      if (updated.length > 0) {
        setActiveConversationId(updated[0].id);
      } else {
        handleNewConversation();
      }
    }
  };

  // -------------------------------------------------------------
  // Scan & Solve Image Analysis Handler
  // -------------------------------------------------------------
  const handleAnalyzeImage = async (
    images: string[],
    instruction: string,
    mode: AnalysisMode
  ): Promise<EducationalAnalysis | null> => {
    setIsAnalyzingImage(true);
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (preferences.customApiKey) {
        headers['x-gemini-key'] = preferences.customApiKey;
      }

      const response = await fetch('/api/analyze-image', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          images,
          instruction,
          mode,
          dialect: preferences.dialect,
          learningLevel: preferences.learningLevel,
          customApiKey: preferences.customApiKey,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'فشلت معالجة الصورة.');
      }

      const data = await response.json();
      const newAnalysis: EducationalAnalysis = {
        id: `analysis-${Date.now()}`,
        title: data.title || 'شرح وحل المسألة',
        subject: data.subject || 'مادة دراسية',
        markdown: data.markdown,
        mode,
        images,
        instruction,
        date: new Date().toLocaleDateString('ar-EG'),
        model: data.model,
      };

      return newAnalysis;
    } catch (err: any) {
      alert(err.message || 'حدث خطأ أثناء معالجة الصورة.');
      return null;
    } finally {
      setIsAnalyzingImage(false);
    }
  };

  // -------------------------------------------------------------
  // Quiz Generator Handlers (Forwarding Images & Difficulty)
  // -------------------------------------------------------------
  const handleGenerateQuiz = async (
    topic: string,
    count: number,
    content?: string,
    difficulty?: QuizDifficulty,
    images?: string[]
  ): Promise<Quiz | null> => {
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (preferences.customApiKey) {
        headers['x-gemini-key'] = preferences.customApiKey;
      }

      const res = await fetch('/api/generate-quiz', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          topic,
          content,
          count,
          difficulty: difficulty || 'thanawya_standard',
          images: images || [],
          customApiKey: preferences.customApiKey,
        }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'فشل إنشاء الاختبار.');
      }

      const data = await res.json();
      const generatedQuiz: Quiz = {
        id: `quiz-${Date.now()}`,
        title: data.quiz?.title || `اختبار في ${topic}`,
        subject: data.quiz?.subject || 'مادة دراسية',
        difficulty: difficulty || 'thanawya_standard',
        questions: data.quiz?.questions || [],
        createdAt: new Date().toISOString(),
      };

      setQuizzes((prev) => [generatedQuiz, ...prev]);
      return generatedQuiz;
    } catch (err: any) {
      alert(err.message || 'حدث خطأ أثناء إعداد الاختبار.');
      return null;
    }
  };

  // Discuss quiz mistakes with tutor
  const handleAskTutorAboutMistakes = (quiz: Quiz) => {
    const incorrect = quiz.questions.filter((q, idx) => quiz.userAnswers?.[idx] !== q.correctAnswer);
    const summary = incorrect
      .map((q, i) => `س${i + 1}: ${q.question} (الإجابة الصحيحة: ${q.options[q.correctAnswer]} - التفسير: ${q.explanation})`)
      .join('\n');

    const prompt = `أنهيت اختباراً في "${quiz.title}"، وأريد مساعدتك في شرح وتبسيط الأسئلة التالية التي أخطأت فيها:\n\n${summary}`;
    setCurrentTab('tutor');
    handleSendChatMessage(prompt);
  };

  // Save analysis to library
  const handleSaveAnalysisToLibrary = (item: EducationalAnalysis) => {
    const isAlreadySaved = savedExplanations.some((e) => e.id === item.id);
    if (isAlreadySaved) {
      setSavedExplanations((prev) => removeExplanation(prev, item.id));
    } else {
      const savedExp: SavedExplanation = {
        id: item.id,
        title: item.title,
        subject: item.subject,
        markdown: item.markdown,
        date: item.date,
        images: item.images,
        instruction: item.instruction,
        mode: item.mode,
      };
      setSavedExplanations((prev) => addOrUpdateExplanation(prev, savedExp));
    }
  };

  // Clear all data
  const handleClearAllData = () => {
    clearAllLocalData();
    setSavedExplanations([]);
    setQuizzes([]);
    const freshConv: Conversation = {
      id: `conv-${Date.now()}`,
      title: 'محادثة المذاكرة الأولى',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: [],
    };
    setConversations([freshConv]);
    setActiveConversationId(freshConv.id);
  };

  const activeConversation =
    conversations.find((c) => c.id === activeConversationId) || conversations[0];

  return (
    <div className="h-[100dvh] max-h-[100dvh] w-full flex flex-col overflow-hidden bg-[#F8FAFC] dark:bg-[#0B0F19] text-slate-800 dark:text-slate-100 font-sans transition-colors">
      {/* Streamlined Header */}
      <Header
        theme={preferences.theme}
        dialect={preferences.dialect}
        onToggleDialect={() =>
          setPreferences((prev) => ({
            ...prev,
            dialect: prev.dialect === 'egyptian' ? 'msa' : 'egyptian',
          }))
        }
        onToggleTheme={() =>
          setPreferences((prev) => ({
            ...prev,
            theme: prev.theme === 'dark' ? 'light' : 'dark',
          }))
        }
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Main View Area (Strictly bounded to viewport between Header & Navigation) */}
      <main className="flex-1 min-h-0 w-full relative overflow-hidden flex flex-col">
        {currentTab === 'tutor' && (
          <AITeacherChat
            conversation={activeConversation}
            conversations={conversations}
            onSelectConversation={(id) => setActiveConversationId(id)}
            onNewConversation={handleNewConversation}
            onRenameConversation={handleRenameConversation}
            onDeleteConversation={handleDeleteConversation}
            onSendMessage={handleSendChatMessage}
            onSaveToLibrary={(item) =>
              setSavedExplanations((prev) => addOrUpdateExplanation(prev, item))
            }
            onStartVoice={() => setIsVoiceModalOpen(true)}
            isGenerating={isGeneratingChat}
            onStopGeneration={handleStopChatGeneration}
            dialect={preferences.dialect}
            onQuickScan={() => setCurrentTab('scanner')}
          />
        )}

        {currentTab === 'scanner' && (
          <ScanScreen
            onAnalyze={handleAnalyzeImage}
            isAnalyzing={isAnalyzingImage}
            onSaveToLibrary={handleSaveAnalysisToLibrary}
            onAskTutor={(context) => {
              setCurrentTab('tutor');
              handleSendChatMessage(context);
            }}
            onGenerateQuiz={(title, markdown) => {
              setCurrentTab('quiz');
              setQuizInitialTopic(title);
              handleGenerateQuiz(title, 3, markdown);
            }}
            savedIds={savedExplanations.map((e) => e.id)}
          />
        )}

        {currentTab === 'quiz' && (
          <QuizScreen
            quizzes={quizzes}
            onSaveQuiz={(quiz) => setQuizzes((prev) => [quiz, ...prev])}
            onGenerateQuiz={handleGenerateQuiz}
            onAskTutorAboutMistakes={handleAskTutorAboutMistakes}
            initialTopic={quizInitialTopic}
          />
        )}

        {currentTab === 'library' && (
          <LibraryScreen
            savedItems={savedExplanations}
            onOpenItem={(item) => {
              setCurrentTab('tutor');
              handleSendChatMessage(`أريد مراجعة هذا الشرح المحفوظ لدي:\n\n${item.markdown}`);
            }}
            onDeleteItem={(id) => setSavedExplanations((prev) => removeExplanation(prev, id))}
          />
        )}
      </main>

      {/* Streamlined Bottom Navigation (4 tabs, pinned right at the bottom) */}
      <Navigation
        currentTab={currentTab}
        onChangeTab={(tab) => setCurrentTab(tab)}
        savedCount={savedExplanations.length}
      />

      {/* Voice Recording Modal */}
      <VoiceRecorderModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        onSubmitTranscription={(text) => handleSendChatMessage(text)}
        language={preferences.language}
        customApiKey={preferences.customApiKey}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        preferences={preferences}
        onUpdatePreferences={(updates) => setPreferences((prev) => ({ ...prev, ...updates }))}
        onClearData={handleClearAllData}
      />
    </div>
  );
}
