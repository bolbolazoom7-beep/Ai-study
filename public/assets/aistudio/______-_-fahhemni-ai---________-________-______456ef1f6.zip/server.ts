import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';

// Support large payloads for image and audio data
app.use(express.json({ limit: '35mb' }));
app.use(express.urlencoded({ extended: true, limit: '35mb' }));

// Helper to extract base64 data and mimeType
function parseDataUrl(dataUrl: string): { mimeType: string; data: string } {
  if (dataUrl.startsWith('data:')) {
    const matches = dataUrl.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
    if (matches && matches.length === 3) {
      return { mimeType: matches[1], data: matches[2] };
    }
  }
  return { mimeType: 'image/jpeg', data: dataUrl };
}

// Clean API key string
function cleanKey(rawKey?: string): string {
  if (!rawKey || typeof rawKey !== 'string') return '';
  return rawKey.trim().replace(/^["'`]+|["'`]+$/g, '');
}

// Global Gemini Client Helper (supports optional manual user API key)
function getGeminiClient(customApiKey?: string): GoogleGenAI {
  const manual = cleanKey(customApiKey);
  const serverKey = cleanKey(process.env.GEMINI_API_KEY);
  const keyToUse = manual || serverKey;

  if (!keyToUse) {
    throw new Error('مفتاح Google Gemini API غير متوفر. يمكنك إضافة مفتاحك الخاص في الإعدادات.');
  }

  return new GoogleGenAI({
    apiKey: keyToUse,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Resilient list of fast Gemini models with automatic quota failover
const FAST_MODELS = [
  'gemini-3.1-flash-lite',
  'gemini-3.1-flash-lite-preview',
  'gemini-flash-latest',
  'gemini-3.5-flash',
  'gemini-3-flash-preview',
  'gemini-3.8-flash',
];

// System instruction generator focused heavily on 3rd Secondary (الثانوية العامة المصرية)
function getStudySystemInstruction(dialect: string = 'egyptian', learningLevel: string = 'high'): string {
  const dialectStyle =
    dialect === 'egyptian'
      ? 'تحدث بأسلوب الأستاذ المصري الخبير في الثانوية العامة، ودود، محفز، دقيق جداً في القوانين، ويشرح بروح المعلم الداعم الذي يريد لطلابه الحصول على الدرجة النهائية.'
      : 'تحدث بلغة عربية فصحى تعليمية مبسطة، أنيقة وسهلة الفهم ومشجعة للغاية.';

  return `أنت الأستاذ "فهّمني | Fahhemni AI" - كبير معلمي الثانوية العامة (الصف الثالث الثانوي).
تطوير وإشراف: بلال أحمد.
المنهج المستهدف: منهج الصف الثالث الثانوي بجمهورية مصر العربية (نماذج الوزارة، امتحانات الثانوية العامة السابقة، بنك الأسئلة، ومنصات الوزارة الرسمية).
أسلوب الشرح: ${dialectStyle}

⚠️ تعليمات وقواعد صارمة لجودة الإجابة:
1. المباشرة والسرعة: ادخل في صلب المسألة أو السؤال فوراً بدون مقدمات مفرطة.
2. الدقة الأكاديمية: التزم بالقوانين والمفاهيم الرسمية للثانوية العامة المصرية (فيزياء، كيمياء، أحياء، رياضيات، لغة عربية، لغة إنجليزية).
3. منع الرموز الغريبة: ممنوع نهائياً استخدام أكواد LaTeX مثل $$ أو \\frac أو \\text أو أي علامات غير مقروءة.
4. التنسيق العربي السليم للرياضيات والعلوم:
   - اكتب القوانين والمعادلات بصيغة نصية عربية واضحة، مثل: (السرعة = المسافة ÷ الزمن) أو (القوة = الكتلة × العجلة) أو (س = ٢ص + ٥).
   - اكتب الكسور بشكل مقروء (مثال: ٣ / ٤ أو نصف أو ربع).
5. تقسيم الإجابة دائماً إلى أقسام بصرية مريحة:
   ### 📌 المعطيات وفكرة السؤال
   ### 📐 القانون المستخدم
   ### 🔢 خطوات الحل خطوة بخطوة (مرقمة وواضحة جداً مع التعليل)
   ### 🎯 الناتج النهائي المباشر (مع وحدات القياس بوضوح)
   ### 💡 تكة امتحان الوزارة (ملاحظة لتجنب الوقوع في فخ السؤال)
6. التشجيع: اختم دائماً بنصيحة ذكية ترفع معنويات طالب الثانوية العامة.`;
}

// -------------------------------------------------------------
// Health / Keys status
// -------------------------------------------------------------
app.get('/api/keys-status', (_req: Request, res: Response) => {
  return res.json({
    hasServerGemini: Boolean(cleanKey(process.env.GEMINI_API_KEY)),
    ready: true,
  });
});

// -------------------------------------------------------------
// Test API Key Endpoint
// -------------------------------------------------------------
app.post('/api/test-key', async (req: Request, res: Response) => {
  try {
    const { apiKey } = req.body;
    const cleanK = cleanKey(apiKey);
    if (!cleanK) {
      return res.status(400).json({ success: false, error: 'يرجى إدخال مفتاح Gemini أولاً.' });
    }

    const ai = new GoogleGenAI({ apiKey: cleanK });
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite',
      contents: 'قل كلمة: تم',
    });

    if (response.text) {
      return res.json({ success: true, message: 'مفتاح Google Gemini سليم ومتصل بنجاح! ⚡' });
    }
    throw new Error('لم يتم استلام رد صالح.');
  } catch (err: any) {
    console.error('Error testing key:', err);
    return res.status(400).json({
      success: false,
      error: 'المفتاح غير صالح أو لم يتم تفعيله. تأكد من نسخه بشكل صحيح من Google AI Studio.',
    });
  }
});

// -------------------------------------------------------------
// 1. Streaming Chat Route (SSE with Multi-Model Quota Fallback)
// -------------------------------------------------------------
app.post('/api/chat-stream', async (req: Request, res: Response) => {
  try {
    const { messages, dialect = 'egyptian', learningLevel = 'high', customApiKey } = req.body;
    const manualKey = cleanKey(customApiKey) || cleanKey(req.headers['x-gemini-key'] as string);

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'الرسائل فارغة' });
    }

    const ai = getGeminiClient(manualKey);
    const systemInstruction = getStudySystemInstruction(dialect, learningLevel);

    const history = messages.slice(0, -1).map((m: any) => ({
      role: m.role === 'model' || m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.text || '' }],
    }));

    const lastMsg = messages[messages.length - 1];
    let messageInput: any = lastMsg.text || 'مرحبا';

    if (lastMsg.images && Array.isArray(lastMsg.images) && lastMsg.images.length > 0) {
      const parts: any[] = [];
      for (const img of lastMsg.images) {
        const { mimeType, data } = parseDataUrl(img);
        parts.push({
          inlineData: {
            mimeType,
            data,
          },
        });
      }
      if (lastMsg.text) {
        parts.push({ text: lastMsg.text });
      }
      messageInput = { parts };
    }

    // Set SSE headers
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    let streamSucceeded = false;
    let lastError: any = null;

    for (const model of FAST_MODELS) {
      try {
        const chat = ai.chats.create({
          model,
          history: history.length > 0 ? history : undefined,
          config: {
            systemInstruction,
            temperature: 0.2,
          },
        });

        const stream = await chat.sendMessageStream({ message: messageInput });

        for await (const chunk of stream) {
          const text = chunk.text;
          if (text) {
            res.write(`data: ${JSON.stringify({ text })}\n\n`);
            if (typeof (res as any).flush === 'function') {
              (res as any).flush();
            }
          }
        }

        streamSucceeded = true;
        break;
      } catch (err: any) {
        lastError = err;
        console.warn(`Model ${model} stream error, falling back to next model...`);
      }
    }

    if (!streamSucceeded) {
      throw lastError || new Error('تعذر توليد الرد حالياً.');
    }

    res.write('data: [DONE]\n\n');
    res.end();
  } catch (error: any) {
    console.error('Streaming chat error:', error);
    if (!res.headersSent) {
      return res.status(500).json({
        error: error.message || 'حدث خطأ في محادثة المعلم الذكي.',
      });
    }
    res.write(`data: ${JSON.stringify({ error: error.message || 'خطأ أثناء المعالجة' })}\n\n`);
    res.write('data: [DONE]\n\n');
    res.end();
  }
});

// -------------------------------------------------------------
// 2. Standard Chat Route (Fast Non-Streaming Fallback)
// -------------------------------------------------------------
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { messages, dialect = 'egyptian', learningLevel = 'high', customApiKey } = req.body;
    const manualKey = cleanKey(customApiKey) || cleanKey(req.headers['x-gemini-key'] as string);

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'الرسائل فارغة' });
    }

    const ai = getGeminiClient(manualKey);
    const systemInstruction = getStudySystemInstruction(dialect, learningLevel);

    const history = messages.slice(0, -1).map((m: any) => ({
      role: m.role === 'model' || m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.text || '' }],
    }));

    const lastMsg = messages[messages.length - 1];
    let messageInput: any = lastMsg.text || 'مرحبا';

    if (lastMsg.images && Array.isArray(lastMsg.images) && lastMsg.images.length > 0) {
      const parts: any[] = [];
      for (const img of lastMsg.images) {
        const { mimeType, data } = parseDataUrl(img);
        parts.push({
          inlineData: {
            mimeType,
            data,
          },
        });
      }
      if (lastMsg.text) {
        parts.push({ text: lastMsg.text });
      }
      messageInput = { parts };
    }

    let lastError: any = null;

    for (const model of FAST_MODELS) {
      try {
        const chat = ai.chats.create({
          model,
          history: history.length > 0 ? history : undefined,
          config: {
            systemInstruction,
            temperature: 0.2,
          },
        });

        const response = await chat.sendMessage({ message: messageInput });

        return res.json({
          text: response.text || '',
          model,
        });
      } catch (err: any) {
        lastError = err;
        console.warn(`Model ${model} chat error, falling back to next...`);
      }
    }

    throw lastError || new Error('تعذر إتمام المحادثة.');
  } catch (error: any) {
    console.error('Error in chat:', error);
    return res.status(500).json({
      error: error.message || 'حدث خطأ في محادثة الأستاذ الذكي.',
    });
  }
});

// -------------------------------------------------------------
// 3. Multimodal Scan & Solve Route (حل المسائل وشرح الصور)
// -------------------------------------------------------------
app.post('/api/analyze-image', async (req: Request, res: Response) => {
  try {
    const { images, instruction, mode = 'auto', dialect = 'egyptian', learningLevel = 'high', customApiKey } = req.body;
    const manualKey = cleanKey(customApiKey) || cleanKey(req.headers['x-gemini-key'] as string);

    if (!images || !Array.isArray(images) || images.length === 0) {
      return res.status(400).json({ error: 'لم يتم توفير صور للتحليل' });
    }

    const ai = getGeminiClient(manualKey);
    const systemInstruction = `${getStudySystemInstruction(dialect, learningLevel)}

تعليمات خاصة بقراءة صور امتحانات ومذكرات الصف الثالث الثانوي:
- استخرج كل معطيات المسألة بدقة متناهية.
- حدد الوحدة والفصل الدراسي والقانون المستخدم وفق كتاب الوزارة.
- اكتب خطوات الحل التفصيلية بالتعليل.
- الناتج النهائي مع وحدات القياس بدقة.`;

    const userPrompt = `حلل واشرح صفحة الكتاب أو المسألة المرفقة بدقة وتنسيق منظم وواضح:
${instruction ? `ملاحظة الطالب: "${instruction}"` : ''}`;

    const imageParts = images.map((imgStr: string) => {
      const { mimeType, data } = parseDataUrl(imgStr);
      return {
        inlineData: {
          mimeType,
          data,
        },
      };
    });

    let lastError: any = null;

    for (const model of FAST_MODELS) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: {
            parts: [...imageParts, { text: userPrompt }],
          },
          config: {
            systemInstruction,
            temperature: 0.15,
          },
        });

        const markdown = response.text || 'تم تحليل المسألة بنجاح.';
        let title = 'شرح وحل المسألة';
        let subject = 'مادة دراسية';

        if (markdown.includes('رياضيات') || markdown.includes('تفاضل') || markdown.includes('معادلة') || markdown.includes('جبر') || markdown.includes('هندسة فراغية') || markdown.includes('استاتيكا') || markdown.includes('ديناميكا')) {
          title = 'مسألة رياضية ثانوية عامة';
          subject = 'رياضيات';
        } else if (markdown.includes('فيزياء') || markdown.includes('سرعة') || markdown.includes('قوة') || markdown.includes('مقاومة') || markdown.includes('كيرشوف') || markdown.includes('أوم') || markdown.includes('فاراداي')) {
          title = 'مسألة وقوانين الفيزياء (3 ثانوي)';
          subject = 'فيزياء';
        } else if (markdown.includes('كيمياء') || markdown.includes('تفاعل') || markdown.includes('عضوي') || markdown.includes('انتقالية')) {
          title = 'مسألة وتطبيقات الكيمياء (3 ثانوي)';
          subject = 'كيمياء';
        } else if (markdown.includes('أحياء') || markdown.includes('DNA') || markdown.includes('مناعة') || markdown.includes('تكاثر') || markdown.includes('دعامة')) {
          title = 'سؤال الأحياء (3 ثانوي)';
          subject = 'أحياء';
        } else if (markdown.includes('English') || markdown.includes('Grammar') || markdown.includes('Vocabulary')) {
          title = 'Thanawya Amma English Exercise';
          subject = 'لغة إنجليزية';
        }

        return res.json({
          markdown,
          title,
          subject,
          mode,
          model,
        });
      } catch (err: any) {
        lastError = err;
        console.warn(`Model ${model} image analysis error, trying next...`);
      }
    }

    throw lastError || new Error('فشلت معالجة الصورة.');
  } catch (error: any) {
    console.error('Error in analyze-image:', error);
    return res.status(500).json({
      error: error.message || 'حدث خطأ أثناء تحليل الصورة الدراسية.',
    });
  }
});

// -------------------------------------------------------------
// 4. Fast Thanawya Amma Quiz Generator (from Image OR Topic + Diagrams)
// -------------------------------------------------------------
app.post('/api/generate-quiz', async (req: Request, res: Response) => {
  try {
    const {
      topic,
      content,
      count = 3,
      difficulty = 'thanawya_standard',
      images = [],
      customApiKey,
    } = req.body;

    const manualKey = cleanKey(customApiKey) || cleanKey(req.headers['x-gemini-key'] as string);
    const ai = getGeminiClient(manualKey);

    const difficultyDesc =
      difficulty === 'ministry_direct'
        ? 'مستوى امتحانات الوزارة المباشرة (فهم وتطبيق مباشر للقوانين بدون لف أو دوران)'
        : difficulty === 'high_achievers'
        ? 'مستوى المتفوقين ونماذج أوائل الجمهورية (تفكير عليا، ربط بين فصول المنهج، وتكات امتحانات قوية)'
        : 'مستوى امتحانات الثانوية العامة القياسية (أسئلة الاختيار من متعدد في مصر، تحليل وتطبيق دقيق)';

    const promptText = `أنت واضع امتحانات خبير في مادة الفيزياء والكيمياء والأحياء والرياضيات للثانوية العامة المصرية (الصف الثالث الثانوي).
المطلوب: توليد اختبار تدريبي عالي الدقة والمطابقة لنماذج الوزارة يتكون من ${count} أسئلة بنظام الاختيار من متعدد (MCQ).
مستوى الصعوبة: ${difficultyDesc}.
الموضوع / الدرس: "${topic || 'مراجعة عامة لمادة من مواد الثانوية العامة'}".
${content ? `محتوى الدرس المستخرج: "${content.slice(0, 1500)}"` : ''}
${images.length > 0 ? 'مرفق صورة لصفحة درس أو مسألة من كتاب الطالب، اعتمد عليها بشكل أساسي في توليد الأسئلة.' : ''}

شروط صارمة لجودة الأسئلة:
1. الأسئلة مأخوذة من صميم منهج الصف الثالث الثانوي المصري وأسئلة امتحانات الثانوية العامة والوزارة (مثل بنك الأسئلة ومنصة حصص مصر).
2. لكل سؤال 4 خيارات ورقم الإجابة الصحيحة وتفسير تفصيلي علمي بسبب الإجابة.
3. للأسئلة التي تتطلب شكلاً توضيحياً أو رسماً بيانياً (مثل دائرة كهربية في الفيزياء، رسم بياني للعلاقة بين متغيرين، شكل خلية أو قطاع في الأحياء، تجربة في الكيمياء)، قم بإنشاء كود SVG نقي في حقل "diagramSvg" يكون بسيطاً وأنيقاً وواضحاً (مع viewBox و stroke و fill مناسب). إذا لم يتطلب السؤال رسماً اجعل diagramSvg فارغاً "".
4. ممنوع استخدام رموز LaTeX أو $$. اكتب المعادلات بالعربية المقروءة.
5. أرجع كود JSON فقط بدون أي نص إضافي وفق الهيكل التالي:
{
  "title": "عنوان الاختبار بالصف الثالث الثانوي",
  "subject": "المادة (فيزياء / كيمياء / أحياء / رياضيات)",
  "questions": [
    {
      "id": "q1",
      "question": "نص السؤال الامتحاني الدقيق؟",
      "options": ["أ) خيار 1", "ب) خيار 2", "ج) خيار 3", "د) خيار 4"],
      "correctAnswer": 0,
      "explanation": "الشرح النموذجي للحل وتوضيح القانون المستخدم.",
      "diagramSvg": "<svg viewBox='0 0 300 120' width='100%' height='100%'>...</svg>",
      "diagramDescription": "وصف الرسم البياني أو الدائرة التوضيحية"
    }
  ]
}`;

    // Handle multimodal images if provided
    let contentParts: any = promptText;
    if (images && Array.isArray(images) && images.length > 0) {
      const parts: any[] = [];
      for (const img of images) {
        const { mimeType, data } = parseDataUrl(img);
        parts.push({
          inlineData: {
            mimeType,
            data,
          },
        });
      }
      parts.push({ text: promptText });
      contentParts = { parts };
    }

    let lastError: any = null;

    for (const model of FAST_MODELS) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: contentParts,
          config: {
            responseMimeType: 'application/json',
            temperature: 0.15,
          },
        });

        const cleanJson = (response.text || '{}').replace(/```json/g, '').replace(/```/g, '').trim();
        const quizData = JSON.parse(cleanJson);

        return res.json({
          quiz: quizData,
          model,
        });
      } catch (err: any) {
        lastError = err;
        console.warn(`Model ${model} quiz error, trying next...`);
      }
    }

    throw lastError || new Error('فشل إنشاء الاختبار.');
  } catch (error: any) {
    console.error('Error generating quiz:', error);
    return res.status(500).json({
      error: error.message || 'فشل إنشاء الاختبار التدريبي.',
    });
  }
});

// -------------------------------------------------------------
// 5. Audio Transcription Route (Gemini 3.5 Transcribe with fallback)
// -------------------------------------------------------------
app.post('/api/transcribe-audio', async (req: Request, res: Response) => {
  try {
    const { audioData, mimeType = 'audio/webm', customApiKey } = req.body;
    const manualKey = cleanKey(customApiKey) || cleanKey(req.headers['x-gemini-key'] as string);

    if (!audioData) {
      return res.status(400).json({ error: 'لم يتم توفير بيانات الصوت' });
    }

    const { data: cleanBase64, mimeType: cleanMime } = parseDataUrl(audioData);
    const ai = getGeminiClient(manualKey);

    const transcribeModels = ['gemini-3.5-transcribe', 'gemini-3.1-flash-lite', 'gemini-flash-latest'];

    for (const model of transcribeModels) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: {
            parts: [
              {
                inlineData: {
                  mimeType: cleanMime || mimeType,
                  data: cleanBase64,
                },
              },
              { text: 'Transcribe this student voice message accurately in Egyptian Arabic or Modern Standard Arabic. Return only the transcription text.' },
            ],
          },
        });

        const transcription = response.text?.trim() || '';
        return res.json({ transcription });
      } catch (err: any) {
        console.warn(`Transcribe model ${model} failed, trying next...`);
      }
    }

    throw new Error('فشل تحويل الصوت إلى نص.');
  } catch (error: any) {
    console.error('Error transcribing audio:', error);
    return res.status(500).json({ error: 'فشل تحويل الصوت إلى نص.' });
  }
});

// -------------------------------------------------------------
// 6. Text-to-Speech Route (Gemini 3.8 Flash Lite TTS)
// -------------------------------------------------------------
app.post('/api/tts', async (req: Request, res: Response) => {
  try {
    const { text, customApiKey } = req.body;
    const manualKey = cleanKey(customApiKey) || cleanKey(req.headers['x-gemini-key'] as string);

    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'لم يتم تقديم نص للقراءة' });
    }

    const sanitizedText = text
      .replace(/[*#_`~[\]()]/g, ' ')
      .replace(/\s+/g, ' ')
      .slice(0, 350)
      .trim();

    if (!sanitizedText) {
      return res.status(400).json({ error: 'النص فارغ بعد التنظيف' });
    }

    const ai = getGeminiClient(manualKey);

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [{ text: sanitizedText }],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      return res.status(500).json({ error: 'لم يتوفر ملف الصوت.' });
    }

    return res.json({
      audioUrl: `data:audio/wav;base64,${base64Audio}`,
    });
  } catch (error: any) {
    console.error('Error generating speech:', error);
    return res.status(500).json({ error: 'فشل تحويل النص لصوت.' });
  }
});

// -------------------------------------------------------------
// Dev & Production Serving Setup
// -------------------------------------------------------------
async function startServer() {
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🎓 فهّمني AI server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
